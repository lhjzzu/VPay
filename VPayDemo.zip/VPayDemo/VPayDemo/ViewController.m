//
//  ViewController.m
//  VPayDemo
//
//  Created by 蚩尤 on 16/5/16.
//  Copyright © 2016年 ouer. All rights reserved.
//

#import "ViewController.h"
#import "VPay.h"
@interface ViewController ()

@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIButton *aliPayBtn = [[UIButton alloc] init];
    aliPayBtn.frame = CGRectMake(100, 100, 100, 100);
    aliPayBtn.backgroundColor = [UIColor redColor];
    [aliPayBtn setTitle:@"支付宝支付" forState:UIControlStateNormal];
    [aliPayBtn addTarget:self action:@selector(aliPayBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aliPayBtn];
    
    UIButton *wxPayBtn = [[UIButton alloc] init];
    wxPayBtn.frame = CGRectMake(100, 250, 100, 100);
    wxPayBtn.backgroundColor = [UIColor redColor];
    [wxPayBtn setTitle:@"微信支付" forState:UIControlStateNormal];
    [wxPayBtn addTarget:self action:@selector(wxPayBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:wxPayBtn];
    
    
    UIButton *unionPayBtn = [[UIButton alloc] init];
    unionPayBtn.frame = CGRectMake(100, 400, 100, 100);
    unionPayBtn.backgroundColor = [UIColor redColor];
    [unionPayBtn setTitle:@"银联支付" forState:UIControlStateNormal];
    [unionPayBtn addTarget:self action:@selector(unionPayBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:unionPayBtn];
}

- (void)aliPayBtnClick:(UIButton *)sender {
    //服务端下发 （这个信息有可能已经失效）
    NSString *sign = @"partner=\"2088811995952100\"&seller_id=\"pc@davebella.com\"&out_trade_no=\"SO16051543065428\"&subject=\"戴维贝拉支付\"&body=\"戴维贝拉订单支付,订单号：SO16051543065428\"&total_fee=\"149.0\"&notify_url=\"http://api.kkkd.com/pay/notify/alipay/app\"&service=\"mobile.securitypay.pay\"&payment_type=\"1\"&_input_charset=\"utf-8\"&it_b_pay=\"10079m\"&sign=\"A40s8d9xJABQtMh9vNE%2BbI0uCpiBOCLClnc54qwX2tgL9ZPFAUZKRzhLHzNuvL276P6uXAbYvGCP1H7x6Xhtb5CdnK%2FiqgO3HXqQVdd4KMHbATcBgxk%2FkTch%2Bis%2BicspSaQLbRLw6OkIkGR%2FYbyfvbVMDhdypmsmztq7FK5XEdw%3D\"&sign_type=\"RSA\"";
    
    [[VPay manager] payWithOrderDic:@{@"sign":sign}  withType:VPAYTYPE_ALIPAY withScheme:@"alipay123" withViewController:nil withCompletion:^(VPayResultStatus status, NSString *msg) {
        
        NSLog(@"status = %@ , msg = %@", @(status), msg);
    }];
    
}

- (void)wxPayBtnClick:(UIButton *)sender {
    
    //服务端下发（这个信息有可能已经失效，微信要用真机测试）
    NSDictionary *orderDic = @{@"appId":@"wx681a54f7179c96d0",
                               @"nonceStr":@"eIQjpuJDlvw8GHYk",
                               @"packageValue":@"Sign=WXPay",
                               @"partnerId":@"1319759701",
                               @"prepayId":@"wx2016051615152302129e26f00887287136",
                               @"sign":@"1D38273765BF155DE0685D23EF73940C",
                               @"timeStamp":@"1463382923",};
    [[VPay manager] payWithOrderDic:orderDic withType:VPAYTYPE_WX withScheme:nil withViewController:nil withCompletion:^(VPayResultStatus status, NSString *msg) {
        NSLog(@"status = %@ , msg = %@", @(status), msg);
        
    }];
}
- (void)unionPayBtnClick:(UIButton *)sender {
     //服务端下发（这个信息有可能已经失效）
    NSDictionary *orderDic = @{@"sign":@"201605161136309426488"};
    
    [[VPay manager] payWithOrderDic:orderDic withType:VPAYTYPE_UNION withScheme:nil withViewController:self withCompletion:^(VPayResultStatus status, NSString *msg) {
        NSLog(@"status = %@ , msg = %@", @(status), msg);
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
