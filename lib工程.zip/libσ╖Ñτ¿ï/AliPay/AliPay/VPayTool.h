//
//  VPayTool.h
//  VPay
//
//  Created by 蚩尤 on 16/5/14.
//  Copyright © 2016年 ouer. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VPayTool : NSObject
/**
 *  判断字符串是否为空
 */
+ (BOOL)isEmpty:(NSString *)string;

@end
